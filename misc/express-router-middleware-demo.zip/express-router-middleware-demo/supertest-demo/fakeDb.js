global.cats = [];

module.exports = cats;